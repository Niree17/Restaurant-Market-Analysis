-- =====================================================================
-- Project 2: Restaurant Market Analysis (Bangalore) | SQL (MySQL 8)
-- File 02: clean the raw data
-- Raw table -> typed table -> one row per restaurant -> cuisine table
-- =====================================================================
USE zomato_project;

-- ---------------------------------------------------------------------
-- STEP 1: Profile the problems in the raw data
-- ---------------------------------------------------------------------
SELECT
    COUNT(*)                                                         AS raw_rows,
    SUM(rate = 'NEW')                                                AS rating_is_new,
    SUM(rate = '-')                                                  AS rating_is_dash,
    SUM(TRIM(rate) = '')                                             AS rating_blank,
    SUM(TRIM(approx_cost) = '')                                      AS cost_blank,
    SUM(approx_cost LIKE '%,%')                                      AS cost_has_comma,
    SUM(TRIM(cuisines) = '')                                         AS cuisines_blank,
    SUM(TRIM(rest_type) = '')                                        AS rest_type_blank,
    SUM(TRIM(location) = '')                                         AS location_blank
FROM restaurants_raw;

-- Exact duplicate rows
SELECT COUNT(*) - COUNT(DISTINCT name, online_order, book_table, rate, votes, location,
                                 rest_type, cuisines, approx_cost, listed_type, listed_city)
       AS exact_duplicate_rows
FROM restaurants_raw;

-- The same restaurant appears once per Zomato listing category
-- (Delivery, Dine-out, Cafes ...), so one restaurant = many raw rows.
SELECT COUNT(*) AS raw_rows,
       COUNT(DISTINCT name, location) AS unique_restaurants
FROM restaurants_raw;

-- ---------------------------------------------------------------------
-- STEP 2: Typed table (fix ratings, votes and cost, trim text)
--   rate   '4.1/5' / '4.1 /5'  -> 4.1       'NEW', '-', blank -> NULL
--   cost   '1,200'             -> 1200      blank             -> NULL
--   rows with no location are dropped (needed for every location query)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS restaurants_typed;
CREATE TABLE restaurants_typed AS
SELECT
    TRIM(name)                                                        AS name,
    TRIM(online_order)                                                AS online_order,
    TRIM(book_table)                                                  AS book_table,
    CASE WHEN TRIM(rate) REGEXP '^[0-9]'
         THEN CAST(TRIM(SUBSTRING_INDEX(TRIM(rate), '/', 1)) AS DECIMAL(2,1))
    END                                                               AS rating,
    CASE WHEN TRIM(votes) REGEXP '^[0-9]+$'
         THEN CAST(TRIM(votes) AS UNSIGNED) ELSE 0
    END                                                               AS votes,
    TRIM(location)                                                    AS location,
    NULLIF(TRIM(rest_type), '')                                       AS rest_type,
    NULLIF(TRIM(cuisines), '')                                        AS cuisines,
    CASE WHEN REPLACE(TRIM(approx_cost), ',', '') REGEXP '^[0-9]+$'
         THEN CAST(REPLACE(TRIM(approx_cost), ',', '') AS UNSIGNED)
    END                                                               AS cost_for_two,
    TRIM(listed_type)                                                 AS listed_type,
    TRIM(listed_city)                                                 AS listed_city
FROM restaurants_raw
WHERE TRIM(location) <> '';

SELECT COUNT(*) AS typed_rows FROM restaurants_typed;

-- ---------------------------------------------------------------------
-- STEP 3: One row per restaurant
-- A restaurant = same name + same location. Keep the listing with the most
-- votes (ROW_NUMBER), which also removes the exact duplicates.
-- Assumption: two outlets with the same name in the same locality are
-- treated as one restaurant (rare in this data).
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS restaurants;
CREATE TABLE restaurants (
    restaurant_id  INT AUTO_INCREMENT PRIMARY KEY,
    name           VARCHAR(255),
    online_order   VARCHAR(10),
    book_table     VARCHAR(10),
    rating         DECIMAL(2,1),
    votes          INT UNSIGNED,
    location       VARCHAR(100),
    rest_type      VARCHAR(100),
    cuisines       VARCHAR(500),
    cost_for_two   INT UNSIGNED,
    price_range    VARCHAR(30),
    INDEX idx_location (location),
    INDEX idx_name (name)
);

INSERT INTO restaurants
    (name, online_order, book_table, rating, votes, location, rest_type,
     cuisines, cost_for_two, price_range)
SELECT name, online_order, book_table, rating, votes, location, rest_type,
       cuisines, cost_for_two,
       CASE WHEN cost_for_two IS NULL   THEN NULL
            WHEN cost_for_two <= 400    THEN '1 Budget (up to 400)'
            WHEN cost_for_two <= 800    THEN '2 Mid (401-800)'
            WHEN cost_for_two <= 1500   THEN '3 Upper-Mid (801-1500)'
            ELSE                             '4 Premium (1500+)'
       END
FROM (
    SELECT t.*,
           ROW_NUMBER() OVER (PARTITION BY name, location
                              ORDER BY votes DESC, rating DESC) AS rn
    FROM restaurants_typed t
) ranked
WHERE rn = 1;

SELECT COUNT(*) AS unique_restaurants,
       SUM(rating IS NULL)       AS no_rating_yet,
       SUM(cost_for_two IS NULL) AS no_cost,
       SUM(cuisines IS NULL)     AS no_cuisine
FROM restaurants;

-- ---------------------------------------------------------------------
-- STEP 4: Split the multi-value cuisines column into one row per cuisine
-- 'North Indian, Mughlai, Chinese' -> 3 rows (max 8 cuisines per restaurant)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS numbers;
CREATE TABLE numbers (n INT PRIMARY KEY);
INSERT INTO numbers (n) VALUES (1),(2),(3),(4),(5),(6),(7),(8),(9),(10);

DROP TABLE IF EXISTS restaurant_cuisines;
CREATE TABLE restaurant_cuisines AS
SELECT r.restaurant_id,
       TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(r.cuisines, ',', nums.n), ',', -1)) AS cuisine
FROM restaurants r
JOIN numbers nums
  ON nums.n <= 1 + LENGTH(r.cuisines) - LENGTH(REPLACE(r.cuisines, ',', ''))
WHERE r.cuisines IS NOT NULL;

ALTER TABLE restaurant_cuisines ADD INDEX idx_rc (restaurant_id, cuisine);

-- ---------------------------------------------------------------------
-- STEP 5: Final checks
-- ---------------------------------------------------------------------
SELECT 'restaurants'        AS tbl, COUNT(*) AS row_count FROM restaurants
UNION ALL SELECT 'restaurant_cuisines', COUNT(*) FROM restaurant_cuisines;

SELECT MIN(rating) AS min_rating, MAX(rating) AS max_rating,
       MIN(cost_for_two) AS min_cost, MAX(cost_for_two) AS max_cost,
       MAX(votes) AS max_votes
FROM restaurants;

SELECT price_range, COUNT(*) AS restaurants
FROM restaurants
GROUP BY price_range
ORDER BY price_range;
