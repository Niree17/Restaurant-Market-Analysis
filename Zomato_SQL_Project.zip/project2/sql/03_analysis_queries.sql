-- =====================================================================
-- Project 2: Restaurant Market Analysis (Bangalore) | SQL (MySQL 8)
-- File 03: business analysis queries
-- Business question: where should a new restaurant open in Bangalore,
-- and which cuisine and price range should it offer?
--
-- Notes
--  * Ratings are averaged only over rated restaurants (NEW / '-' ignored).
--  * Votes = number of Zomato ratings, used as a proxy for customer demand.
--  * Small groups are excluded with HAVING so one or two restaurants
--    cannot distort an average.
-- =====================================================================
USE zomato_project;

-- =====================================================================
-- SECTION A: MARKET OVERVIEW (basic)
-- =====================================================================

-- Q1. Overall picture of the market
SELECT COUNT(*)                              AS restaurants,
       COUNT(DISTINCT location)              AS locations,
       COUNT(rating)                         AS rated_restaurants,
       ROUND(AVG(rating), 2)                 AS avg_rating,
       ROUND(AVG(cost_for_two))              AS avg_cost_for_two,
       ROUND(100 * AVG(online_order = 'Yes'), 1) AS pct_online_order,
       ROUND(100 * AVG(book_table = 'Yes'), 1)   AS pct_table_booking
FROM restaurants;

-- Q2. Top 10 locations by number of restaurants (most competitive areas)
SELECT location,
       COUNT(*)                   AS restaurants,
       ROUND(AVG(rating), 2)      AS avg_rating,
       ROUND(AVG(cost_for_two))   AS avg_cost_for_two,
       SUM(votes)                 AS total_votes
FROM restaurants
GROUP BY location
ORDER BY restaurants DESC
LIMIT 10;

-- Q3. Restaurant types: how many, how well rated, how expensive
SELECT rest_type,
       COUNT(*)                   AS restaurants,
       ROUND(AVG(rating), 2)      AS avg_rating,
       ROUND(AVG(cost_for_two))   AS avg_cost_for_two,
       ROUND(AVG(votes))          AS avg_votes
FROM restaurants
WHERE rest_type IS NOT NULL
GROUP BY rest_type
HAVING COUNT(*) >= 100
ORDER BY restaurants DESC;

-- Q4. Share of restaurants in each rating band (window function for %)
SELECT CASE WHEN rating < 3.0 THEN '1 Below 3.0'
            WHEN rating < 3.5 THEN '2 3.0 - 3.4'
            WHEN rating < 4.0 THEN '3 3.5 - 3.9'
            WHEN rating < 4.5 THEN '4 4.0 - 4.4'
            ELSE                   '5 4.5 and above'
       END                                              AS rating_band,
       COUNT(*)                                         AS restaurants,
       ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 1) AS pct_of_rated
FROM restaurants
WHERE rating IS NOT NULL
GROUP BY rating_band
ORDER BY rating_band;

-- =====================================================================
-- SECTION B: CUISINE AND PRICE (intermediate)
-- =====================================================================

-- Q5. Most common cuisines and how they perform
SELECT rc.cuisine,
       COUNT(*)                   AS restaurants,
       ROUND(AVG(r.rating), 2)    AS avg_rating,
       ROUND(AVG(r.votes))        AS avg_votes,
       ROUND(AVG(r.cost_for_two)) AS avg_cost_for_two
FROM restaurant_cuisines rc
JOIN restaurants r ON r.restaurant_id = rc.restaurant_id
GROUP BY rc.cuisine
ORDER BY restaurants DESC
LIMIT 10;

-- Q6. Cuisines with at least 100 restaurants, ranked by average rating
SELECT rc.cuisine,
       COUNT(*)                   AS restaurants,
       ROUND(AVG(r.rating), 2)    AS avg_rating,
       ROUND(AVG(r.votes))        AS avg_votes,
       ROUND(AVG(r.cost_for_two)) AS avg_cost_for_two
FROM restaurant_cuisines rc
JOIN restaurants r ON r.restaurant_id = rc.restaurant_id
GROUP BY rc.cuisine
HAVING COUNT(*) >= 100
ORDER BY avg_rating DESC
LIMIT 10;

-- Q7. Price range vs rating and demand
SELECT price_range,
       COUNT(*)                AS restaurants,
       ROUND(AVG(rating), 2)   AS avg_rating,
       ROUND(AVG(votes))       AS avg_votes
FROM restaurants
WHERE price_range IS NOT NULL
GROUP BY price_range
ORDER BY price_range;

-- Q8. Does online ordering or table booking go with better results?
SELECT online_order,
       book_table,
       COUNT(*)                AS restaurants,
       ROUND(AVG(rating), 2)   AS avg_rating,
       ROUND(AVG(votes))       AS avg_votes,
       ROUND(AVG(cost_for_two)) AS avg_cost_for_two
FROM restaurants
GROUP BY online_order, book_table
ORDER BY online_order DESC, book_table DESC;

-- =====================================================================
-- SECTION C: WINDOW FUNCTIONS AND CTEs (advanced)
-- =====================================================================

-- Q9. Top 3 restaurants in each of the 8 busiest locations
--     (ROW_NUMBER per location; at least 200 votes so ratings are reliable;
--      a few names in the source file are garbled text, so they are skipped)
WITH busiest AS (
    SELECT location
    FROM restaurants
    GROUP BY location
    ORDER BY COUNT(*) DESC
    LIMIT 8
),
ranked AS (
    SELECT r.location, r.name, r.rating, r.votes, r.cost_for_two,
           ROW_NUMBER() OVER (PARTITION BY r.location
                              ORDER BY r.rating DESC, r.votes DESC) AS rank_in_location
    FROM restaurants r
    JOIN busiest b ON b.location = r.location
    WHERE r.votes >= 200 AND r.rating IS NOT NULL
      AND r.name COLLATE utf8mb4_bin NOT LIKE '%Ã%'
)
SELECT location, rank_in_location, name, rating, votes, cost_for_two
FROM ranked
WHERE rank_in_location <= 3
ORDER BY location, rank_in_location;

-- Q10. Locations rated above or below the Bangalore average
--      (AVG() OVER () gives the city-wide average on every row)
WITH location_stats AS (
    SELECT location,
           COUNT(rating)           AS rated_restaurants,
           ROUND(AVG(rating), 2)   AS avg_rating
    FROM restaurants
    GROUP BY location
    HAVING COUNT(rating) >= 50
)
SELECT location,
       rated_restaurants,
       avg_rating,
       ROUND(AVG(avg_rating) OVER (), 2)              AS city_avg_of_locations,
       ROUND(avg_rating - AVG(avg_rating) OVER (), 2) AS diff_vs_city,
       RANK() OVER (ORDER BY avg_rating DESC)         AS rating_rank
FROM location_stats
ORDER BY rating_rank
LIMIT 10;

-- Q11. Top restaurant chains (same name, 10+ outlets)
SELECT name,
       COUNT(*)                   AS outlets,
       ROUND(AVG(rating), 2)      AS avg_rating,
       ROUND(AVG(cost_for_two))   AS avg_cost_for_two,
       SUM(votes)                 AS total_votes
FROM restaurants
GROUP BY name
HAVING COUNT(*) >= 10
ORDER BY outlets DESC
LIMIT 10;

-- =====================================================================
-- SECTION D: WHERE TO OPEN (the business answer)
-- =====================================================================

-- Q12. Opportunity locations = high demand, low competition
--      demand      = average votes per restaurant (top quartile)
--      competition = number of restaurants      (bottom half)
--      quality     = average rating at or above the market average
WITH location_stats AS (
    SELECT location,
           COUNT(*)                AS restaurants,
           ROUND(AVG(votes))       AS avg_votes,
           ROUND(AVG(rating), 2)   AS avg_rating,
           ROUND(AVG(cost_for_two)) AS avg_cost_for_two
    FROM restaurants
    GROUP BY location
    HAVING COUNT(*) >= 40
),
scored AS (
    SELECT s.*,
           NTILE(4) OVER (ORDER BY avg_votes DESC)  AS demand_quartile,     -- 1 = highest demand
           NTILE(4) OVER (ORDER BY restaurants ASC) AS competition_quartile -- 1 = least competition
    FROM location_stats s
)
SELECT location, restaurants, avg_votes, avg_rating, avg_cost_for_two,
       demand_quartile, competition_quartile
FROM scored
WHERE demand_quartile = 1
  AND competition_quartile <= 2
  AND avg_rating >= (SELECT AVG(rating) FROM restaurants)
ORDER BY avg_votes DESC;

-- Q13. Best-performing cuisine in each of the 8 busiest locations
--      (at least 10 rated restaurants per cuisine in that location)
WITH busiest AS (
    SELECT location
    FROM restaurants
    GROUP BY location
    ORDER BY COUNT(*) DESC
    LIMIT 8
),
loc_cuisine AS (
    SELECT r.location, rc.cuisine,
           COUNT(r.rating)         AS rated_restaurants,
           ROUND(AVG(r.rating), 2) AS avg_rating,
           ROUND(AVG(r.votes))     AS avg_votes
    FROM restaurants r
    JOIN busiest b             ON b.location = r.location
    JOIN restaurant_cuisines rc ON rc.restaurant_id = r.restaurant_id
    GROUP BY r.location, rc.cuisine
    HAVING COUNT(r.rating) >= 10
),
ranked AS (
    SELECT lc.*,
           ROW_NUMBER() OVER (PARTITION BY location
                              ORDER BY avg_rating DESC, avg_votes DESC) AS rn
    FROM loc_cuisine lc
)
SELECT location, cuisine, rated_restaurants, avg_rating, avg_votes
FROM ranked
WHERE rn = 1
ORDER BY avg_rating DESC;

-- Q14. Cuisine gap: well-rated, in demand, but not crowded
--      (50 to 600 restaurants, rating above market average, ranked by demand)
SELECT rc.cuisine,
       COUNT(*)                   AS restaurants,
       ROUND(AVG(r.rating), 2)    AS avg_rating,
       ROUND(AVG(r.votes))        AS avg_votes,
       ROUND(AVG(r.cost_for_two)) AS avg_cost_for_two
FROM restaurant_cuisines rc
JOIN restaurants r ON r.restaurant_id = rc.restaurant_id
GROUP BY rc.cuisine
HAVING COUNT(*) BETWEEN 50 AND 600
   AND AVG(r.rating) > (SELECT AVG(rating) FROM restaurants)
ORDER BY avg_votes DESC
LIMIT 10;

-- Q15. Price sweet spot inside the opportunity locations
--      (reuses the Q12 logic in a CTE, then looks at price ranges there)
WITH location_stats AS (
    SELECT location, COUNT(*) AS restaurants, AVG(votes) AS avg_votes, AVG(rating) AS avg_rating
    FROM restaurants
    GROUP BY location
    HAVING COUNT(*) >= 40
),
scored AS (
    SELECT s.*,
           NTILE(4) OVER (ORDER BY avg_votes DESC)  AS demand_quartile,
           NTILE(4) OVER (ORDER BY restaurants ASC) AS competition_quartile
    FROM location_stats s
),
opportunity AS (
    SELECT location FROM scored
    WHERE demand_quartile = 1 AND competition_quartile <= 2
      AND avg_rating >= (SELECT AVG(rating) FROM restaurants)
)
SELECT r.price_range,
       COUNT(*)                AS restaurants,
       ROUND(AVG(r.rating), 2) AS avg_rating,
       ROUND(AVG(r.votes))     AS avg_votes
FROM restaurants r
JOIN opportunity o ON o.location = r.location
WHERE r.price_range IS NOT NULL
GROUP BY r.price_range
ORDER BY r.price_range;
