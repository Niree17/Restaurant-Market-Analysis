-- =====================================================================
-- Project 2: Restaurant Market Analysis (Bangalore) | SQL (MySQL 8)
-- File 01: create the database and load the raw CSV
-- =====================================================================
-- Every raw column is VARCHAR on purpose: the source has values such as
-- '4.1/5', 'NEW', '-' and '1,200' that would break a numeric import.
-- Types are fixed in 02_clean_data.sql.
-- =====================================================================

CREATE DATABASE IF NOT EXISTS zomato_project;
USE zomato_project;

DROP TABLE IF EXISTS restaurants_raw;
CREATE TABLE restaurants_raw (
    name          VARCHAR(255),
    online_order  VARCHAR(10),
    book_table    VARCHAR(10),
    rate          VARCHAR(20),
    votes         VARCHAR(20),
    location      VARCHAR(100),
    rest_type     VARCHAR(100),
    cuisines      VARCHAR(500),
    approx_cost   VARCHAR(20),
    listed_type   VARCHAR(100),
    listed_city   VARCHAR(100)
) CHARACTER SET utf8mb4;

-- OPTION A: load straight from the CSV (change the path to your own file).
-- LOCAL needs local_infile enabled: SET GLOBAL local_infile = 1;
-- and OPT_LOCAL_INFILE=1 in the Workbench connection (Advanced tab).
--
-- LOAD DATA LOCAL INFILE 'C:/zomato/zomato_trimmed.csv'
-- INTO TABLE restaurants_raw
-- CHARACTER SET utf8mb4
-- FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
-- LINES TERMINATED BY '\n'
-- IGNORE 1 LINES;

-- OPTION B (no file paths needed): run 00_load_raw_data.sql instead,
-- which contains the same 51,717 rows as INSERT statements.

-- Check after loading: expect 51,717 rows
-- SELECT COUNT(*) FROM restaurants_raw;
